# Chat App with PHP and Node.JS
Files of chat app with PHP and Node.JS tutorial at Hyvor Developer

Visit Tutorial Here: [https://developer.hyvor.com/php/chat-app-with-php-nodejs](https://developer.hyvor.com/php/chat-app-with-php-nodejs)

![Article Image](https://developer.hyvor.com/images/php-nodejs-chat.png)
