<?php
$mysqli = new mysqli('localhost', 'username', 'passsword', 'database');
